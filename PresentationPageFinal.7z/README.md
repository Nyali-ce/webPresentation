# To host the website locally, run

npm i
npm run dev

# to run in development mode, or

npm run start

# to run in production mode.

# Opening the html file directly (in dist) in the browser will not work without disabling CORS policy in your browser.
